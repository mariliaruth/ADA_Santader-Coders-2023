# aula 1
Paradigmas de programação

Conceitos de Programação Orientada a Objetos

Classes e objetos em Python

Atributos e métodos em Python

Método construtor e inicialização de objetos (__init__)

# aula 2

Encapsulamento

Modificadores de acesso

Métodos get e set

Criação de getters e setters através de decorators

Criação de getters e setters através da função property

# aula 3

Revisão das aulas 1 e 2
Exercícios

# aula 4

Módulos em Python
Pacotes em Python

# aula 5

Métodos mágicos aritméticos

Métodos mágicos de comparação

Métodos mágicos de representação

# aula 6

Atributos estáticos

Métodos estáticos

# aula 7

Polimorfismo

# aula 8

Revisão dos tópicos do módulo

# aula 9

Aula dedicada à devolutiva da avaliação por rubrica / auto-avaliação
